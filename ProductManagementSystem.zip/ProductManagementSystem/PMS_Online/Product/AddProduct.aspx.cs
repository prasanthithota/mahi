﻿using ProductBL;
using ProductException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using System.Drawing;

namespace PMS_Online.Product
{
    public partial class AddProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                    FillGrid();
                    lblPId.Text = ProductValidations.GetProductID_BL().ToString();
                    
                }
                catch (PMSException ex)
                { 
                    lbl_error.Text = ex.Message; 
                }
                catch (SystemException ex)
                { 
                    lbl_error.Text = ex.Message; 
                }
            }
        }

        private void FillGrid()
        {
            List<Entity.Product> plist = ProductValidations.DisplayAllProductBL();
            if (plist.Count == 0)
            {
                lbl_error.Text = "Product Table is Empty.";
                gvProducts.Visible = false;
            }
            else
            {
                gvProducts.Visible = true;
                gvProducts.DataSource = plist;
                gvProducts.DataBind();
            }
        }

        private void AddProductPL()
        {
            try
            {
                Entity.Product newproduct = new Entity.Product();                
                newproduct.ProductName = txtPName.Text;
                bool chkprice;
                decimal p_price;
                chkprice = decimal.TryParse(txtPrice.Text, out p_price);
                newproduct.Price = p_price;
                newproduct.CategoryId = Convert.ToInt32(txtCategory.Text);
                bool productadded = ProductValidations.AddProductBL(newproduct);
                if (!productadded)
                    throw new PMSException("Product Cannot be added");
                else
                {
                    lbl_error.ForeColor = Color.Black;
                    lbl_error.Text = "Product Added Successfully";
                    FillGrid();
                }
            }
            catch (PMSException ex)
            {
                lbl_error.Text = ex.Message;
            }
            catch (SystemException e)
            { 
                lbl_error.Text = e.Message; 
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            AddProductPL();
        }
        
    }
}