﻿using ProductBL;
using ProductException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PMS_Online.Product
{
    public partial class DeleteProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if(ProductValidations.DeleteProductBL(int.Parse(txtPId.Text)))
                {
                    Response.Write
                        ("<script>alert('Product Deleted');window.location.href='/Product/Welcome.aspx';</script>");
                }
            }
            catch (PMSException ex)
            {
                lbl_error.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                lbl_error.Text = ex.Message;
            }
        }
    }
}