﻿using ProductBL;
using ProductException;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PMS_Online.Product
{
    public partial class EditProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                Entity.Product newproduct = new Entity.Product();
                newproduct.ProductID = int.Parse(txtPId.Text);
                newproduct.ProductName = txtPName.Text;
                bool chkprice;
                decimal p_price;
                chkprice = decimal.TryParse(txtPrice.Text, out p_price);
                newproduct.Price = p_price;
                newproduct.CategoryId = Convert.ToInt32(txtCategory.Text);
                bool productadded = ProductValidations.EditProductBL(newproduct);
                if (!productadded)
                    throw new PMSException("Product Cannot be added");
                else
                {
                    lbl_error.ForeColor = Color.Black;
                    lbl_error.Text = "Product details saved Successfully";                    
                }
            }
            catch (PMSException ex)
            {
                lbl_error.Text = ex.Message;
            }
            catch (FormatException ex)
            {
                lbl_error.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                lbl_error.Text = ex.Message;
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                List<Entity.Product> p = ProductValidations.SearchProductBL(int.Parse(txtPId.Text));
                if (p != null)
                {
                    decimal price = Math.Round(p[0].Price,2);
                    txtPName.Text = p[0].ProductName.Trim();
                    txtPrice.Text = price.ToString();
                    txtCategory.Text = p[0].CategoryId.ToString();
                }
                else
                {
                    lbl_error.Text = "No product Found. Enter Valid Product Id to search.";
                }
            }
            catch (PMSException ex)
            {
                lbl_error.Text = ex.Message;
            }
            catch (FormatException ex)
            {
                lbl_error.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                lbl_error.Text = ex.Message;
            }
        }
    }
}