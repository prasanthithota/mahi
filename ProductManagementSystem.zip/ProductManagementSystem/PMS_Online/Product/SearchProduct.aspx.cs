﻿using ProductBL;
using ProductException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PMS_Online.Product
{
    public partial class SearchProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Thread.Sleep(5000);
            try
            {
                List<Entity.Product> p = ProductValidations.SearchProductBL(int.Parse(txtPId.Text));
                if (p != null)
                {
                    dvProdut.DataSource = p;
                    dvProdut.DataBind();
                }
                else
                {
                    lbl_error.Text = "No product Found. Enter Valid Product Id to search.";
                }
            }
            catch (PMSException ex)
            {
                lbl_error.Text = ex.Message;
            }
            catch (FormatException ex)
            {
                lbl_error.Text = ex.Message;
            }
            catch(SystemException ex)
            {
                lbl_error.Text = ex.Message;
            }
        }
    }
}