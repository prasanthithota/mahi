﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using ProductBL;
using ProductException;
using System.Web.Configuration;
using System.Web.Security;

namespace PMS_Online
{
    /// <summary>
    /// Purpose:Login Form to check the user credentials
    /// Author:Sangeetha
    /// Date Modified:9-Nov-2016
    /// </summary>
    public partial class LoginForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            //Accessing the cookie
            HttpCookie cookie = Request.Cookies["login"];
            //if cookie is not null restore the details in textbox
            if (cookie != null)
            {
                txtLoginID.Text = cookie.Values["loginID"];
                txtPassword.Text = cookie.Values["pwd"];
            }


        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            LoginUser user = new LoginUser();
            string username = null;
            HttpCookie cookie = null;
            try
            {
                //Fetching records for login from textboxes
                user.LoginID = txtLoginID.Text;
                user.Password = txtPassword.Text;

                //Checking the login ID and password is valid or not 
                username = ProductValidations.ValidateLogin(user);

                if (username != null)
                {
                    //Add user name in session
                    Session["user"] = username;

                    if (chkRemember.Checked)
                    {
                        //Create cookie to remember user id and password
                        cookie = new HttpCookie("login");
                        cookie.Values.Add("loginID", user.LoginID);
                        cookie.Values.Add("pwd", user.Password);
                        cookie.Expires = DateTime.Now.AddMinutes(60);
                        Response.Cookies.Add(cookie);
                    }

                    //Redirect to AddProduct Page
                    FormsAuthentication.RedirectFromLoginPage(user.LoginID, false);

                    // Response.Redirect("ProductForm.aspx",true);
                }
                else
                    throw new PMSException("Login ID or Password is incorrect");
            }
            catch (PMSException p)
            {
                lblError.Text = p.Message;
            }
            catch (SystemException ex)
            {
                lblError.Text = ex.Message;
            }
        }
    }
}
