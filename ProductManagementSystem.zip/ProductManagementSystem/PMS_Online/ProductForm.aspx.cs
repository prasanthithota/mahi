﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using ProductException;
using ProductBL;
namespace PMS_Online
{
    /// <summary>
    /// Purpose:Product Form to insert the Product Details using BL methods
    /// Author:Sangeetha
    /// Date Modified:9-Nov-2016
    /// </summary>
    public partial class ProductForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }
        private void AddProductPL()
        {
           
        }

        protected void btn_submit_Click(object sender, EventArgs e)
        {
            
           
        }

        protected void btn_reset_Click(object sender, EventArgs e)
        {
            
        }

    }
}