﻿CREATE TABLE [dbo].[Login_Detail](
	[LoginID] [varchar](15) NULL,
	[Password] [varchar](15) NULL
) ON [PRIMARY]
insert into Login_Detail values('admin','admin')
CREATE TABLE [dbo].[product_table](
	[productId] [int] IDENTITY(1,1) NOT NULL,
	[product_name] [nvarchar](30) NOT NULL,
	[price] [money] NULL,
	[categoryID] [int] NULL,
 CONSTRAINT [pk_pid] PRIMARY KEY CLUSTERED 
(
	[productId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


CREATE procedure [dbo].[usp_InsertProduct]
@pname nvarchar(30),
@price money,
@categoryId int
as
begin
Insert dbo.product_table(product_name,price,categoryID) values(@pname,@price,@categoryId)
end

create procedure [dbo].[usp_showAllProducts]
as
begin
select * from dbo.product_table
end

create proc [dbo].[usp_IDENTITY]
as
begin select IDENT_CURRENT('dbo.product_table')+IDENT_INCR('dbo.product_table')
end

create procedure [dbo].[usp_searchProduct]
(
@pid int
)
as
begin
select * from dbo.product_table where productId = @pid
end

alter procedure [dbo].[usp_UpdateProduct]
@pname nvarchar(30),
@price money,
@categoryId int,
@pid int
as
begin
Update dbo.product_table
set product_name=@pname,price=@price,categoryID=@categoryId
where productId = @pid
end

create procedure [dbo].[usp_deleteProduct]
(
@pid int
)
as
begin
delete from dbo.product_table where productId = @pid
end