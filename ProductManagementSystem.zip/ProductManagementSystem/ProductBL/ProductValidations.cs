﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions ;
using System.Data;
using System.Data.Common;
using Entity;
using ProductException;
using ProductDAL;

namespace ProductBL
{
    public class ProductValidations
    {
        public static string ValidateLogin(LoginUser user)
        {
            string username = null;

            try
            {
                //Calling ValidateLogin function from DAL layer
                username = ProductOperations.ValidateUser(user);
            }
            catch (PMSException  p)
            {
                throw p;
            }
            catch (SystemException e)
            {
                throw e;
            }

            return username;
        }

        private static bool ValidateProduct(Product product)
        {

            bool validproduct = true;
            StringBuilder message = new StringBuilder();
            
            if (!(Regex.IsMatch(product.ProductName, @"^[A-Z][a-z]+$")))
            {
                validproduct = false;
                message.Append(Environment.NewLine + "ProductName must contain Characters only");
            }

            if (!(Regex.IsMatch(product.Price.ToString(), @"^[0-9]+$")))
            {
                validproduct = false;
                message.Append(Environment.NewLine + "Product Price must contain 6 digits only");
            }

            if ((product.Price.ToString().Equals(string.Empty)))
            {
                validproduct = false;
                message.Append(Environment.NewLine + "Product Price is Required");
            }

            if (validproduct == false)
            {
                throw new PMSException(message.ToString());
            }
            return validproduct;
        }

        /// <summary>
        /// To validate the Product and to add the Product to Collection List by 
        /// calling the AddProduct method of DAL
        /// </summary>
        /// <param name="product"></param>
        /// <returns>Bool</returns>
        public static bool AddProductBL(Product product)
        {
            bool productadded = false;
            try
            {
                if (ValidateProduct(product))
                {
                    productadded = ProductDAL.ProductOperations.AddProductDAL(product);

                }
            }
            catch (PMSException e)
            { throw e; }
            return productadded;
        }

        //Function to Display all products from Collection
        public static List<Product> DisplayAllProductBL()
        {
            List<Product> plist = new List<Product>();
            try
            {
                plist = ProductDAL.ProductOperations.ShowAllProductsDAL();
                if (plist == null)
                    throw new PMSException("No Product Found");
            }
            catch (PMSException p)
            {
                throw;
            }
            catch (SystemException e)
            {
                Console.WriteLine(e.Message);
            }
            return plist; // Returns the list of Products

        }

        public static int GetProductID_BL()
        {
            return ProductOperations.GetNextProductID_DAL();
        }

        public static List<Product> SearchProductBL(int productId)
        {
            return ProductOperations.SearchProductDAL(productId);
        }

        public static bool EditProductBL(Product product)
        {
            bool productadded = false;
            try
            {
                if (ValidateProduct(product))
                {
                    productadded = ProductDAL.ProductOperations.EditProductDAL(product);
                }
            }
            catch (PMSException e)
            { 
                throw e; 
            }
            return productadded;
        }

        public static bool DeleteProductBL(int productId)
        {
            bool productadded = false;
            try
            {
                productadded = ProductDAL.ProductOperations.DeleteProductDAL(productId);                
            }
            catch (PMSException e)
            {
                throw e;
            }
            return productadded;
        }
    }
}
