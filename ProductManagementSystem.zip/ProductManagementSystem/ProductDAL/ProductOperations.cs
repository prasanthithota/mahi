﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using Entity;
using ProductException;
namespace ProductDAL
{
 public  class ProductOperations
    {

     public static string ValidateUser(LoginUser user)
     {
         string username = null;
         try
         {
             //Creating command on connection using CreateCommand fuD:\ToShare\M3\ADO.NET\ProductManagementSystem\PMS_Online\App_Data\nction
             DbCommand cmd = DataConnection.CreateCommand ();
             //Assigning command text to command object
             cmd.CommandText = "SELECT LoginID FROM Login_Detail WHERE LoginID=@LoginID AND Password=@Password";
             cmd.CommandType = CommandType.Text;
             //Creating SqlParameters and adding to command object
             DbParameter loginID = cmd.CreateParameter();
             loginID.ParameterName = "@LoginID";
             loginID.DbType = DbType.String;
             loginID.Size = 15;
             loginID.Value = user.LoginID;
             cmd.Parameters.Add(loginID);

            DbParameter password = cmd.CreateParameter();
             password.ParameterName = "@Password";
             password.DbType = DbType.String ;
             password.Size = 15;
             password.Value = user.Password;
             cmd.Parameters.Add(password);

             //Open connection
             cmd.Connection.Open();

             //Execute command
             DbDataReader dr = cmd.ExecuteReader ();

             //If data reader has rows user is valid
             if (dr.HasRows)
             {
                 dr.Read();
                 username = dr[0].ToString();
             }
             dr.Close();
             cmd.Connection.Close();
         }
         catch (SystemException e)
         {
             throw;
         }
         return username;
     }

        public static bool AddProductDAL(Product newproduct)
        {
            bool productAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "dbo.usp_insertProduct";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@pname";
                param.DbType = DbType.StringFixedLength ;
                param.Size = 30;
                param.Value = newproduct.ProductName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@price";
                param.DbType = DbType.Currency;
                param.Value = newproduct.Price ;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@categoryId";
                param.DbType = DbType.Int32 ;
                param.Value = newproduct.CategoryId;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    productAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new PMSException (errormessage);
            }
            return productAdded;

        }

        public static List<Product> ShowAllProductsDAL()
        {
            List<Product> productList = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "dbo.usp_showAllProducts";

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    productList = new List<Product>();
                    foreach (DataRow row in dataTable.Rows)
                    {
                        Product product = new Product();
                        product.ProductID = (int)row["productId"];
                        product.ProductName = row["product_name"].ToString();
                        product.Price = Convert.ToDecimal(row["price"].ToString());
                        product.CategoryId = (int)row["categoryID"];
                        productList.Add(product);
                    }
                  }
            }
            catch (DbException ex)
            {
                throw new PMSException(ex.Message);
            }
            return productList;
        }

        public static int GetNextProductID_DAL()
        {
            int nxtid;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "[dbo].[usp_IDENTITY]";
                nxtid = Convert.ToInt32(DataConnection.ExecuteScalarCommand(command));
            }
            catch (DbException e)
            { throw e; }
                return nxtid;
        
        }

        public static List<Product> SearchProductDAL(int productId)
        {
            List<Product> plist = null;
            Product p = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "dbo.usp_searchProduct";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@pid";
                param.DbType = DbType.Int32;                
                param.Value = productId;
                command.Parameters.Add(param);
                
                DataTable dt = DataConnection.ExecuteSelectCommand(command);
                if (dt.Rows.Count > 0)
                {
                    plist = new List<Product>();
                    p = new Product
                    {
                        ProductID = Convert.ToInt32(dt.Rows[0]["ProductID"].ToString()),
                        ProductName = dt.Rows[0]["Product_Name"].ToString(),
                        Price = Convert.ToDecimal(dt.Rows[0]["Price"].ToString()),
                        CategoryId = Convert.ToInt32(dt.Rows[0]["CategoryId"].ToString())
                    };
                    plist.Add(p);
                }
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new PMSException(errormessage);
            }
            return plist;
        }

        public static bool EditProductDAL(Product newproduct)
        {
            bool productAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "dbo.usp_updateProduct";

                DbParameter param = command.CreateParameter();
                param = command.CreateParameter();
                param.ParameterName = "@pid";
                param.DbType = DbType.Int32;
                param.Value = newproduct.ProductID;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@pname";
                param.DbType = DbType.StringFixedLength;
                param.Size = 30;
                param.Value = newproduct.ProductName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@price";
                param.DbType = DbType.Currency;
                param.Value = newproduct.Price;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@categoryId";
                param.DbType = DbType.Int32;
                param.Value = newproduct.CategoryId;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    productAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new PMSException(errormessage);
            }
            return productAdded;
        }

        public static bool DeleteProductDAL(int productId)
        {
            bool productAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "dbo.usp_DeleteProduct";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@pid";
                param.DbType = DbType.Int32;                
                param.Value = productId;
                command.Parameters.Add(param);                

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    productAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage = string.Empty;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new PMSException(errormessage);
            }
            return productAdded;
        }
    }
}
