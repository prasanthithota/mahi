﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;

namespace ProductDAL
{
    class DataConnection
    {
        //Create and prepare a new DBCommand object on a new Connection
        public static DbCommand CreateCommand()
        {
            //Obtain the database provider name
            string dataproviderName = ProductConfiguration.ProviderName;
            //Obtain the database ConnectionString
            string dataconnectionString=ProductConfiguration.ConnectionString;
            DbProviderFactory datafactory= DbProviderFactories.GetFactory(dataproviderName);
        //obtain the Connection object
            DbConnection connection = datafactory.CreateConnection();
             //Set the Connection string
            connection.ConnectionString=dataconnectionString;
        //Create command object specific to the Connection
               DbCommand command = connection.CreateCommand();
            //Set the Command Type as Stored Procedure
            command.CommandType=CommandType.StoredProcedure;
            return command;

        }

        public static DataTable ExecuteSelectCommand(DbCommand command)
        {
            DataTable table = null;
            DbDataReader reader = null;
            try
            {
                table = new DataTable();
                command.Connection.Open();
                reader = command.ExecuteReader();
                table.Load(reader);
            }

            catch (DbException e)
            { throw e; }
            finally 
            {
                if (command.Connection.State == ConnectionState.Open)
                    command.Connection.Close();
            }
            return table;
        }
        //Method to be called when the command returns a scalar value
        public static object ExecuteScalarCommand(DbCommand command)
        {
            object data = null;
            try
            {
                command.Connection.Open();
                data = command.ExecuteScalar();
            }
            catch (DbException e) { throw; }
            finally 
            {
                if (command.Connection.State == ConnectionState.Open)
                    command.Connection.Close();
            }

                        return data;
        }
        public static int ExecuteNonQueryCommand(DbCommand command)
        {
            int rowaffected = -1;
            try
            {
                command.Connection.Open();
                rowaffected = command.ExecuteNonQuery();
                return rowaffected;
            }
            finally
            {
                command.Connection.Close();
            }

            
        }    
    }
}
