﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace ProductDAL
{
    public class ProductConfiguration
    {
       private static string providerName;

        public static string ProviderName
        {
            get { return ProductConfiguration.providerName; }
            set { ProductConfiguration.providerName = value; }
        }
        private static string connectionString;

        public static string ConnectionString
        {
            get { return ProductConfiguration.connectionString; }
            set { ProductConfiguration.connectionString = value; }
        }

        static ProductConfiguration()
        {
            providerName = ConfigurationManager.ConnectionStrings["productConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["productConnection"].ConnectionString;

        }
    }
}
