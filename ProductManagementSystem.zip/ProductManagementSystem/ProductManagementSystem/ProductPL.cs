﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.Common ;
using System.Data.SqlClient;
using Entity;
using ProductException;
using ProductDAL;
using ProductBL;

namespace ProductManagementSystem
{
    public partial class ProductPL : Form
    {
        public ProductPL()
        {
            InitializeComponent();
        }

        private void ProductPL_Load(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection();
            sqlcon.ConnectionString = ConfigurationManager.ConnectionStrings["productConnection"].ToString();
            SqlDataAdapter da = new SqlDataAdapter();
            SqlCommand cmd = new SqlCommand("select * from group3.category_table",sqlcon);
            da.SelectCommand = cmd;
            DataSet ds_category = new DataSet();
            da.Fill(ds_category, "Category");
            cb_category.DataSource = ds_category.Tables[0];
            cb_category.DisplayMember = ds_category.Tables[0].Columns[1].ToString();
            cb_category.ValueMember = ds_category.Tables[0].Columns[0].ToString();
            txt_productId.Text = ProductValidations.GetProductID_BL().ToString();
        
        
        }
        private void ClearFields()
        {
            txt_price.Clear();
            txt_productname.Clear();
        
        }
        private void button2_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private  void AddProductPL()
        {
            try
            {
                Product newproduct = new Product();
                //   newproduct.ProductID = ProductValidations.GetProductID_BL();
                newproduct.ProductName = txt_productname.Text;
                bool chkprice;
                double p_price;
                chkprice = Double.TryParse(txt_price.Text, out p_price);
                newproduct.Price = p_price ;
                newproduct.CategoryId = Convert.ToInt32(cb_category.SelectedValue);
                bool productadded = ProductValidations.AddProductBL(newproduct);
                if (!productadded) throw new PMSException("Product Cannot be added");
                else MessageBox.Show("Product Added Successfully");

            }
            catch (PMSException ex)
            { MessageBox.Show(ex.Message); }
            catch (DbException e)
            { MessageBox.Show(e.Message); }

            }

        private void button1_Click(object sender, EventArgs e)
        {
            AddProductPL();
        }
    }
}
