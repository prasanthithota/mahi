﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity
{
    /// <summary>
    /// Purpose:To create an Entity Class named LoginUser for declaring the Properties
    /// Author:Sangeetha
    /// Date Modified:9-Nov-2016
    /// </summary>
   public class LoginUser
    {
        
            //Gets or Sets LoginID
            public string LoginID { get; set; }
            //Gets or Sets Password
            public string Password { get; set; }
        }
    
}
