﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{

    public class ElectricityBill
    {
        public int CustomerId { get; set; }
        public string Name { get; set; }
        public int LastMonthMeterReading { get; set; }
        public int CurrentMonthMeterReading { get; set; }
        public int UnitsConsumed { get; set; }
        public int TotalAmount { get; set; }
    }
}
