﻿CREATE PROC [tejaswinin].[SPX_Delete_M4_150819_ElectricityBill]
(
@custid INT
)
AS
BEGIN

DELETE FROM tejaswinin.ElectricityBill WHERE CustomerId = @custid 

END


drop procedure [tejaswinin].[SPX_Delete_M4_150819_ElectricityBill]
--Update-----------------

CREATE PROC [tejaswinin].[SPX_Update_M4_150819_ElectricityBill]
(
@custid INT,
@name varchar(20)

)
AS
BEGIN
UPDATE tejaswinin.ElectricityBill
SET Name=@name
WHERE CustomerId = @custid
END

-------Search--------------------
CREATE PROC [tejaswinin].[SPX_Search_M4_150819_ElectricityBill]
(
@custid INT
)
AS
BEGIN
SELECT * FROM tejaswinin.ElectricityBill WHERE CustomerId = @custid
END

drop procedure [tejaswinin].[SPX_Search_M4_150819_ElectricityBill]