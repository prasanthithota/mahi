﻿using EBillDAL;
using Entity;
using Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EBillBusinessLL
{
    /// <summary>
    /// Author:-Tejaswini(150819)
    /// Description:-to connect the LoginUserBillOperations to the ElectricityBillSystem
    /// Time:-9-7-2018
    /// </summary>
    public class LoginUserValidations
    {
        #region ValidateLogin
        public static string ValidateLogin(LoginUser user)
        {
            string userName = "";
            try
            {
                userName = LoginUserOperations.ValidateLogin(user);
            }
            catch (LoginUserException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return userName;
        }
        #endregion
    }
}
