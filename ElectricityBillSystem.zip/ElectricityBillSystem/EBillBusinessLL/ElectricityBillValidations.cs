﻿using EBillDAL;
using Entity;
using Exception;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EBillBusinessLL
{
    /// <summary>
    /// Author:-Tejaswini(150819)
    /// Description:-to connect the ElectricityBillOperations to the ElectricityBillSystem
    /// Time:-9-7-2018
    /// </summary>
    public class ElectricityBillValidations
    {
        #region InsertDetails
        public static int insertDetails(ElectricityBill ebill)
        {
            int recordsAffected = 0;
            try
            {
                recordsAffected = ElectricityBillOpeartions.insertDetails(ebill);
            }
            catch (ElectricityBillException ex)
            {
                throw ex;
            }
            catch(SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }
        public static int GetStud_code()
        {
            return 1;
        }
        #endregion

        #region DisplayDetails
        public static List<ElectricityBill> DisplayDetails()
        {
            List<ElectricityBill> studList = null;
            try
            {
                studList = ElectricityBillOpeartions.DisplayDetails();

            }
            catch (ElectricityBillException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return studList;
        }
        #endregion

        #region UpdateDetails
        public static int updateDetails(ElectricityBill ebill)
        {
            int recordsAffected = 0;
            try
            {
                recordsAffected = ElectricityBillOpeartions.updateDetails(ebill);
            }
            catch (ElectricityBillException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;

        }
        #endregion

        #region DeleteDetails
        public static int deleteDetails(int CustomerId)
        {
            int recordsAffected = 0;
            try
            {
                recordsAffected = ElectricityBillOpeartions.deleteDetails(CustomerId); ;
            }
            catch (ElectricityBillException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }
        #endregion

        #region SearchCustomer
        public static ElectricityBill searchCustomer(int CustomerId)
        {
            ElectricityBill ebill = null;

            try
            {
                ebill = ElectricityBillOpeartions.searchCustomer(CustomerId);
            }
            catch (ElectricityBillException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return ebill;
        }
        #endregion
    }
}
