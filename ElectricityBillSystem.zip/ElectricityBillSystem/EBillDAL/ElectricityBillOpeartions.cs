﻿using Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EBillDAL
{
    /// <summary>
    /// Author:-Tejaswini(150819)
    /// Description:-To connect to the Procedures in the Sql
    /// Time:-9-7-2018
    /// </summary>
    public class ElectricityBillOpeartions
    {
        #region insertdetails
        public static int insertDetails(ElectricityBill ebill)
        {
            int recordsAffected = 0;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[tejaswinin].[SPX_Insert_M4_150819_EBill]";

                //cmd.Parameters.AddWithValue("@cid", ebill.CustomerId);
                cmd.Parameters.AddWithValue("@name", ebill.Name);
                cmd.Parameters.AddWithValue("@lastmonthmeterreading", ebill.LastMonthMeterReading);

                cmd.Parameters.AddWithValue("@currentmonthmeterreading", ebill.CurrentMonthMeterReading);
                cmd.Parameters.AddWithValue("@Units", ebill.UnitsConsumed);
                cmd.Parameters.AddWithValue("@total", ebill.TotalAmount);
                
                //SqlParameter outputParameter = new SqlParameter();
                //outputParameter.ParameterName = "@cid";
                //outputParameter.SqlDbType = System.Data.SqlDbType.Int;
                //outputParameter.Direction = System.Data.ParameterDirection.Output;
                //cmd.Parameters.Add(outputParameter);
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();

            }
            catch (SqlException)
            {
                throw ;
            }
            catch (SystemException)
            {
                throw ;
            }

            return recordsAffected;
        }
        #endregion

        #region DisplayDetails
        public static List<ElectricityBill> DisplayDetails()
        {
            List<ElectricityBill> ebillList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[tejaswinin].[SPX_SelectAll_M4_150819_EBill]";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                   ebillList = new List<ElectricityBill>();
                    while (dr.Read())
                    {
                        ElectricityBill ebill = new ElectricityBill();
                        ebill.CustomerId = Convert.ToInt32(dr[0]);
                        ebill.Name = dr[1].ToString();
                        ebill.LastMonthMeterReading = Convert.ToInt32(dr[2]);
                        ebill.CurrentMonthMeterReading = Convert.ToInt32(dr[3]);
                        ebill.UnitsConsumed = Convert.ToInt32(dr[4]);
                        ebill.TotalAmount= Convert.ToInt32(dr[5]);
                        ebillList.Add(ebill);
                    }
                }
                dr.Close();
                cmd.Connection.Close();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }


            return ebillList;
        }
        #endregion

        #region SearchCustomer

        public static ElectricityBill searchCustomer(int CustomerId)
        {
            ElectricityBill ebill = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[tejaswinin].[SPX_Search_M4_150819_ElectricityBill]";

                cmd.Parameters.AddWithValue("@custid", CustomerId);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    ebill = new ElectricityBill();
                    ebill.CustomerId = Convert.ToInt32(dr[0]);
                    ebill.Name = dr[1].ToString();
                    ebill.LastMonthMeterReading = Convert.ToInt32(dr[2]);
                    ebill.CurrentMonthMeterReading = Convert.ToInt32(dr[3]);
                    ebill.UnitsConsumed = Convert.ToInt32(dr[4]);
                    ebill.TotalAmount=Convert.ToInt32(dr[5]);
                }
                cmd.Connection.Close();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }


            return ebill;
        }
        #endregion

        #region UpdateDetails
        public static int updateDetails(ElectricityBill ebill)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[tejaswinin].[SPX_Update_M4_150819_ElectricityBill]";

                cmd.Parameters.AddWithValue("@custid", ebill.CustomerId);
                cmd.Parameters.AddWithValue("@name", ebill.Name);
             

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }


            return recordsAffected;
        }
        #endregion

        #region DeleteDetails
        public static int deleteDetails(int CustomerId)
        {
            int recordsAffected = 0;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[tejaswinin].[SPX_Delete_M4_150819_ElectricityBill]";


                cmd.Parameters.AddWithValue("@custid", CustomerId);



                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();

            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }

            return recordsAffected;
        }
    }
    #endregion
}
