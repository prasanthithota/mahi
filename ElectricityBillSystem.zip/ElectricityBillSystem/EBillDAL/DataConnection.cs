﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EBillDAL
{
    /// <summary>
    /// Author:-Tejaswini(150819)
    /// Description:-To connect to the SQL Server
    /// Time:-9-7-2018
    /// </summary>
    public class DataConnection
    {
        #region GenerateCommand

        public static SqlCommand GenerateCommand()
        {
            SqlConnection con = null;
            SqlCommand cmd = null;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn2"].ConnectionString);
                cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }

            return cmd;
        }
    }
    #endregion
}
