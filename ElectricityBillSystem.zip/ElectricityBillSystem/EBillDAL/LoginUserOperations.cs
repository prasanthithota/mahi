﻿using Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EBillDAL
{
    /// <summary>
    /// Author:-Tejaswini(150819)
    /// Description:-To validate the Login Page
    /// Time:-9-7-2018
    /// </summary>
    public class LoginUserOperations
    {
        #region ValidateLogin
        public static string ValidateLogin(LoginUser user)
        {
            string userName = "";

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[tejaswinin].[SPX_ValidateLogin_M4_150819_LoginUser]";

                cmd.Parameters.AddWithValue("@username", user.UserName);
                cmd.Parameters.AddWithValue("@password", user.Password);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    userName = dr["UserName"].ToString();
                }
                cmd.Connection.Close();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }

            return userName;
        }
    }
    #endregion
}
