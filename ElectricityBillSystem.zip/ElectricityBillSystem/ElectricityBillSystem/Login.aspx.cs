﻿using EBillBusinessLL;
using Entity;
using Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectricityBillSystem
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                LoginUser user = new LoginUser();
                user.UserName = txtUserName.Text;
                user.Password = txtPassword.Text;
                string UserName = LoginUserValidations.ValidateLogin(user);
                if (UserName != "")
                {
                    Session["user"] = UserName;
                    //Response.Redirect("Welcome.aspx");
                         FormsAuthentication.RedirectFromLoginPage(user.UserName, false);
                }
                else
                {
                    throw new LoginUserException("UserName/Password is Incorrect ");
                }
            }
            catch (LoginUserException ex)
            {
                lblError.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                lblError.Text = ex.Message;
            }
        }
    }
}