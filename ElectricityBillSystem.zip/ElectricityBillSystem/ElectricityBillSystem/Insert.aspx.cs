﻿using EBillBusinessLL;
using Entity;
using Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectricityBillSystem
{
    /// <summary>
    /// Author:-Tejaswini(150819)
    /// Description:-Insert page is created
    /// Time:-9-7-2018
    /// </summary>
    public partial class Insert : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            Master.Menu = true;
            Master.Logout = true;
           // lblWelcome.Text = "Welcome " + Session["user"];


        }

        protected void tnCalculate_Click(object sender, EventArgs e)
        {
            txtunits.Text = (Convert.ToInt32(TextBox2.Text) - Convert.ToInt32(TextBox1.Text)).ToString();
            int UnitsConsumed = Convert.ToInt32(txtunits.Text);
            int TotalAmount;
            int charge;
            if (UnitsConsumed > 250)
            {
                charge = 6;
                TotalAmount = UnitsConsumed * charge + 100;
                txttotal.Text = TotalAmount.ToString();

            }
            else if (UnitsConsumed > 101 && UnitsConsumed <= 250)
            {
                charge = 3;
                TotalAmount = UnitsConsumed * charge + 100;
                txttotal.Text = TotalAmount.ToString();


            }
            else
            {
                charge = 1;
                TotalAmount = UnitsConsumed * charge + 100;
                txttotal.Text = TotalAmount.ToString();

            }
        }


        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {

                ElectricityBill ebill = new ElectricityBill();
                //txtStudCode.Text = StudentValidations.GetStud_code().ToString();
                //stud.Stud_Code = Convert.ToInt32(txtStudCode.Text);
                ebill.CustomerId = Convert.ToInt32(txtcustid.Text);
                ebill.Name = txtName.Text;
                ebill.LastMonthMeterReading = Convert.ToInt32(TextBox1.Text);
                ebill.CurrentMonthMeterReading = Convert.ToInt32(TextBox2.Text);
                ebill.UnitsConsumed = Convert.ToInt32(txtunits.Text);
                ebill.TotalAmount = Convert.ToInt32(txttotal.Text);


                int recordsAffected = ElectricityBillValidations.insertDetails(ebill);

                if (recordsAffected > 0)
                {
                    Response.Write("<script type='text/javascript'>alert('Student Record Inserted Successfully');</script>");
                }
                else
                {
                    throw new ElectricityBillException("Student record not inserted");
                }
            }
            catch (ElectricityBillException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }
    }
}