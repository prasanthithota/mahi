﻿using EBillBusinessLL;
using Entity;
using Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElectricityBillSystem
{
    public partial class Search : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            Master.Menu = true;
            Master.Logout = true;
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                ElectricityBill ebill = new ElectricityBill();

                int id = Convert.ToInt32(txtcustid.Text);
                ebill = ElectricityBillValidations.searchCustomer(id);

                txtName.Text = ebill.Name;
                //Response.Write("<script type='text/javascript'>alert('" + txtName.Text + "');</script>");
                txtcurrentmonth.Text = ebill.CurrentMonthMeterReading.ToString();
                txtlastmonth.Text = ebill.LastMonthMeterReading.ToString();
                txtunits.Text = ebill.UnitsConsumed.ToString();
                txttotal.Text = ebill.UnitsConsumed.ToString();

            }

            catch (ElectricityBillException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }

            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                ElectricityBill ebill = new ElectricityBill();
                ebill.CustomerId = Convert.ToInt32(txtcustid.Text);
                ebill.Name = txtName.Text;
                ebill.LastMonthMeterReading = Convert.ToInt32(txtlastmonth.Text);
                ebill.CurrentMonthMeterReading= Convert.ToInt32(txtcurrentmonth.Text);
                ebill.UnitsConsumed = Convert.ToInt32(txtunits.Text);
                ebill.TotalAmount = Convert.ToInt32(txttotal.Text);
                int recordsAffected = ElectricityBillValidations.updateDetails(ebill);


                if (recordsAffected > 0)
                {
                    Response.Write("<script type='text/javascript'>alert('Student Record Updated Successfully');</script>");
                }
                else
                {
                    throw new ElectricityBillException("Student record cannnot be updated");
                }
            }
            catch (ElectricityBillException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ElectricityBill ebill = new ElectricityBill();
                int id = Convert.ToInt32(txtcustid.Text);

                int rowsAffected = ElectricityBillValidations.deleteDetails(id);

                if (rowsAffected > 0)
                {
                    Response.Write("<script type='text/javascript'>alert('ElectricityBill Record Deleted Successfully');</script>");
                }
                else
                {
                    throw new ElectricityBillException("ElectricityBill record cannnot be Deleted!!");
                }
            }
            catch (ElectricityBillException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }
    }
}