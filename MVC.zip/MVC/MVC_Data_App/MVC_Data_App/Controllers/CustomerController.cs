﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_Data_App.Models;

namespace MVC_Data_App.Controllers
{
    public class CustomerController : Controller
    {
        static List<Customer> clist = new List<Customer>();

        // GET: Customer
        public ActionResult Index()
        {
            return View(clist);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Customer cobj)
        {
            if (ModelState.IsValid)
            {
                clist.Add(cobj);
                return View();
            }
            else
            {
                return View();
            }
           
        }
    }
}