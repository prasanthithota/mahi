﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVC_Data_App.Models
{
    public class Customer
    {
        [Required(ErrorMessage="Id is required")]        
        [Range(1,100,ErrorMessage="between 1 to 100")]        
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [RegularExpression("[a-z]{3,5}",ErrorMessage="min 3 max 5")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Gender is required")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Date of Birth is required")]
        public DateTime DateOfBirth { get; set; }
    }
}