﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;

namespace DataAccessLayer
{
    public class CityDal
    {
        static List<City> cityList = new List<City>()
        {
            new City
            {
                CityId =1,CityName="New York"
            },
            new City
            {
                CityId =2,CityName="London"
            }
        };

        public bool AddCity(City c)
        {
            try
            {
                cityList.Add(c);
                return true;
            }
            catch (Exception)
            {                
                throw;
            }
        }

        public List<City> Display()
        {
            return cityList;
        }

        public bool EditCity(City c)
        {
            City cobj = cityList.Find(x => x.CityId == c.CityId);
            cobj.CityName = c.CityName;
            return true;
        }

        public bool DeleteCity(City c)
        {
            City cobj = cityList.Find(x => x.CityId == c.CityId);
            cityList.Remove(cobj);
            return true;
        }

        public City Search(int id)
        {
            City cobj = cityList.Find(x => x.CityId == id);
            return cobj;
        }
    }
}
