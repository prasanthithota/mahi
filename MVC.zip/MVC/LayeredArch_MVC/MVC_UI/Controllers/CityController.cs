﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAccessLayer;
using Entity;

namespace MVC_UI.Controllers
{
    public class CityController : Controller
    {

        public JsonResult ASD()
        {

            var data = "['Name':'John','Id':'1']";
            return Json(data,"text/html",JsonRequestBehavior.AllowGet);
        }

        // GET: City
        [Route("List")]
        public ActionResult GetCities()
        {
            CityDal cd = new CityDal();
            List<City> clist = cd.Display();
            return View(clist);

        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(City c)
        {
            CityDal cd = new CityDal();
            cd.AddCity(c);
            return View();
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            CityDal cd = new CityDal();
            City c = cd.Search(id);
            return View(c);
        }

        [HttpPost]
        public ActionResult Edit(int id, City cobj)
        {
            CityDal cd = new CityDal();
            City c = cd.Search(id);
            if (c != null)
            {
                cd.EditCity(cobj);
                return View();
            }
            else
            {
                return View();
            }
            
        }

        [HttpGet]
        public ActionResult Details(int id)
        {
            CityDal cd = new CityDal();
            City c = cd.Search(id);
            return View(c);
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            CityDal cd = new CityDal();
            City c = cd.Search(id);
            return View(c);
        }

        [HttpPost]
        public ActionResult Delete(int id, City cobj)
        {
            CityDal cd = new CityDal();
            City c = cd.Search(id);
            if (c != null)
            {
                cd.DeleteCity(cobj);
                return View();
            }
            else
            {
                return View();
            }

        }
    }
}