﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EntityFramework_Demo.Models;

namespace EntityFramework_Demo.Controllers
{
    public class CityController : Controller
    {
        ChennaiTraining_15NovEntities context = new ChennaiTraining_15NovEntities();

        // GET: City
        public ActionResult Index()
        {
            var query = (from c in context.Cities
                         select c).ToList();
            return View(query);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(City c)
        {
            context.Cities.Add(c);
            context.SaveChanges();
            return View();
        }
    }
}