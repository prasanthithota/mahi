﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FirstMVCApp.Controllers
{
    public class MyController : Controller
    {
        //// GET: My
        //public ContentResult SayHello()
        //{
        //    return Content("Hello");
        //}

        [HttpGet]
        public ActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Add(string txtFirst,string txtSecond)
        {
            int n1 = int.Parse(txtFirst);
            int n2 = Convert.ToInt32(txtSecond);
            int res = n1 + n2;
            ViewData["addition"] = res;
            return View();
        }

        public ActionResult Home()
        {
            return View();
        }
    }
}