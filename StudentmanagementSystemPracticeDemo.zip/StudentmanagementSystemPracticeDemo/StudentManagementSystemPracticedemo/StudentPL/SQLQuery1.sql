﻿create schema maheswari;
create table [maheswari].[M4_150938_Student](
[Stud_Code] NUMERIC(6) NOT NULL,
[Stud_Name]  VARCHAR(30) NOT NULL,
[Dept_Code] NUMERIC(2) NULL,
[Stud_Dob] DATETIME NULL,
[Address] VARCHAR(30) NULL,
PRIMARY KEY CLUSTERED ([Stud_Code] ASC),
FOREIGN KEY ([Dept_Code]) REFERENCES [maheswari].[M4_150938_Department] ([Dept_code])
);



CREATE TABLE [maheswari].[M4_150938_Department] (
    [Dept_code] NUMERIC (2)  NOT NULL,
    [Dept_Name] VARCHAR (30) NULL,
    PRIMARY KEY CLUSTERED ([Dept_code] ASC),
    UNIQUE NONCLUSTERED ([Dept_Name] ASC)
);

CREATE TABLE [maheswari].[M4_150938_LoginUser](

[UserName] VARCHAR (20) NULL,
[Password] VARCHAR (20) NULL

);

INSERT INTO maheswari.M4_150938_LoginUser (UserName,Password)
VALUES ('LordShiva','Shiva');
INSERT INTO maheswari.M4_150938_LoginUser (UserName,Password)
VALUES ('LordEshwar','Eshwar');

select * from maheswari.M4_150938_LoginUser

CREATE PROC [maheswari].[SPX_Insert_M4_150938_Student]
(
	@scode		INT,
	@sname		VARCHAR(50),
	@dcode		INT,
	@dob		DATE,
	@address	VARCHAR(50)
)
AS
BEGIN
	INSERT INTO maheswari.M4_150938_Student(Stud_Code, Stud_Name, Dept_Code, Stud_Dob, Address)
	VALUES (@scode, @sname, @dcode, @dob, @address)
END

CREATE PROC [maheswari].[SPX_Search_M4_150938_Student]
(
	@scode		INT
)
AS
BEGIN
	SELECT * FROM maheswari.M4_150938_Student WHERE Stud_Code = @scode
END

CREATE PROC [maheswari].[SPX_Update_M4_150938_Student]
(
	@scode		INT,
	@dcode		INT,
	@address	VARCHAR(50)
)
AS
BEGIN
	UPDATE maheswari.M4_150938_Student
	SET Dept_Code = @dcode,
		Address = @address
	WHERE Stud_Code = @scode
END

CREATE PROC [maheswari].[SPX_Delete_M4_150938_Student]
(
	@scode		INT
)
AS
BEGIN
	DELETE FROM maheswari.M4_150938_Student WHERE Stud_Code = @scode
END

CREATE PROC [maheswari].[SPX_SelectAll_M4_150938_Student]
AS
BEGIN
	SELECT * FROM maheswari.M4_150938_Student
END

CREATE PROC [maheswari].[SPX_ValidateLogin_M4_150938_LoginUser]
(
	@username	VARCHAR(20),
	@password	VARCHAR(20)
)
AS
BEGIN
	SELECT UserName
	FROM maheswari.M4_150938_LoginUser
	WHERE UserName = @username AND Password = @password
END