﻿using StudentExceptions;
using StudentManagementBAL;
using StudentPL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentManagementPL
{
    public partial class SearchStudent : System.Web.UI.Page
    {
        

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("Login.aspx");
            }

            Master.Logout = true;
            Master.Menu = true;
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                Student stud = new Student();

                int id = Convert.ToInt32(txtStudCode.Text);
                stud = StudentValidations.searchStudent(id);

                txtStudName.Text = stud.Stud_Name;
                ddlcode.Text = stud.Dept_Code.ToString();
                txtDOB.Text = stud.Stud_Dob.ToString("yyyy-MM-dd");
                txtAddress.Text = stud.Address;

            }

            catch (StudentException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }

            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Student stud = new Student();
                stud.Stud_Code = Convert.ToInt32(txtStudCode.Text);
                stud.Stud_Name = txtStudName.Text;
                stud.Dept_Code = Convert.ToInt32(ddlcode.Text);
                stud.Stud_Dob = Convert.ToDateTime(txtDOB.Text);
                stud.Address = txtAddress.Text;

                int recordsAffected = StudentValidations.updateStudent(stud);


                if (recordsAffected > 0)
                {
                    Response.Write("<script type='text/javascript'>alert('Student Record Updated Successfully');</script>");
                }
                else
                {
                    throw new StudentException("Student record cannnot be updated");
                }
            }
            catch (StudentException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                Student stud = new Student();
                int id = Convert.ToInt32(txtStudCode.Text);

                int rowsAffected = StudentValidations.deleteStudent(id);

                if (rowsAffected > 0)
                {
                    Response.Write("<script type='text/javascript'>alert('Student Record Deleted Successfully');</script>");
                }
                else
                {
                    throw new StudentException("Student record cannnot be Deleted!!");
                }
            }
            catch (StudentException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }
    }
}