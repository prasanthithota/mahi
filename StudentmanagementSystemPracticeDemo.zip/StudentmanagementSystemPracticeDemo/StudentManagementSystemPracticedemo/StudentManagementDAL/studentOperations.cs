﻿using StudentPL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementDAL
{
    public class studentOperations
    {
        public static int insertStudent(Student stud)
        {
            int recordsAffected = 0;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[maheswari].[SPX_Insert_M4_150938_Studentsss]";
                
                cmd.Parameters.AddWithValue("@sname", stud.Stud_Name);
                cmd.Parameters.AddWithValue("@dcode", stud.Dept_Code);
                cmd.Parameters.AddWithValue("@dob", stud.Stud_Dob);

                cmd.Parameters.AddWithValue("@address", stud.Address);
                SqlParameter outputParameter = new SqlParameter();
                outputParameter.ParameterName = "@scode";
                outputParameter.SqlDbType = System.Data.SqlDbType.Int;
                outputParameter.Direction = System.Data.ParameterDirection.Output;
                cmd.Parameters.Add(outputParameter);
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
        public static int deleteStudent(int Stud_Code)
        {
            int recordsAffected = 0;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[maheswari].[SPX_Delete_M4_150938_Student]";


                cmd.Parameters.AddWithValue("@scode", Stud_Code);



                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
        public static Student searchStudent(int Stud_Code)
        {
            Student stud = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[maheswari].[SPX_Search_M4_150938_Student]";

                cmd.Parameters.AddWithValue("@scode", Stud_Code);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    stud = new Student();
                    stud.Stud_Code = Convert.ToInt32(dr["Stud_Code"]);
                    stud.Stud_Name = dr["Stud_Name"].ToString();
                    stud.Dept_Code = Convert.ToInt32(dr["Dept_Code"]);
                    stud.Stud_Dob = Convert.ToDateTime(dr["Stud_Dob"]);
                    stud.Address = dr["Address"].ToString();
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }
        public static int updateStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[maheswari].[SPX_Update_M4_150938_Student]";

                cmd.Parameters.AddWithValue("@scode", stud.Stud_Code);
                cmd.Parameters.AddWithValue("@dcode", stud.Dept_Code);
                cmd.Parameters.AddWithValue("@address", stud.Address);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
        public static List<Student> DisplayStudents()
        {
            List<Student> studList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[maheswari].[SPX_SelectAll_M4_150938_Student]";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    studList = new List<Student>();
                    while (dr.Read())
                    {
                        Student stud = new Student();
                        stud.Stud_Code = Convert.ToInt32(dr["Stud_Code"]);
                        stud.Stud_Name = dr["Stud_Name"].ToString();
                        stud.Dept_Code = Convert.ToInt32(dr["Dept_Code"]);
                        stud.Stud_Dob = Convert.ToDateTime(dr["Stud_Dob"]);
                        stud.Address = dr["Address"].ToString();

                        studList.Add(stud);
                    }
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }

        public static int GetNextStudentID()
        {

            int id;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "[maheswari].[SPX_GetNextID_M4_150938_Student]";

                cmd.Connection.Open();
                id = (int)cmd.ExecuteScalar();

                cmd.Connection.Close();

            }

            catch (SqlException ex)
            {
                throw ex;

            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return id;
        }
    }
}
