﻿using StudentExceptions;
using StudentManagementDAL;
using StudentPL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementBAL
{
    public class StudentValidations
    {
        public static int insertStudent(Student stud)
        {
            int recordsAffected = 0;
            try
            {
                recordsAffected = studentOperations.insertStudent(stud);
            }
            catch(StudentException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }
        public static int deleteStudent(int Stud_Code)
        {
            int recordsAffected = 0;
            try
            {
                recordsAffected = studentOperations.deleteStudent(Stud_Code);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }
        public static int updateStudent(Student stud)
        {
            int recordsAffected = 0;
            try
            {
                recordsAffected = studentOperations.updateStudent(stud);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;

        }
        public static int GetStud_code()
        {
            return studentOperations.GetNextStudentID();
        }

        public static Student searchStudent(int Stud_Code)
        {
            Student stud = null;
           
            try
            {
                stud = studentOperations.searchStudent(Stud_Code);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return stud;
        }
        public static List<Student> DisplayStudents()
        {
            List<Student> studList = null;
            try
            {
                studList = studentOperations.DisplayStudents();

            }
            catch(StudentException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return studList;
        }
    }
}
