﻿using StudentExceptions;
using StudentManagementDAL;
using StudentPL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementBAL
{
    public class LoginUserValidations
    {
        public static string ValidateLogin(LoginUser user)
        {
            string userName = "";
            try
            {
                userName = LoginUserOperations.ValidateLogin(user);
            }
            catch(LoginUserException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return userName;
        }


    }
}
